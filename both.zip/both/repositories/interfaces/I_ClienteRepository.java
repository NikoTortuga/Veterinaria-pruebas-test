package grupo_vet.veterinaria.repositories.interfaces;
import grupo_vet.veterinaria.entities.Mascota;

import java.sql.SQLException;
import java.util.List;

public interface I_ClienteRepository {

}
