package grupo_vet.veterinaria.repositories;
import grupo_vet.veterinaria.entities.Mascota;
import grupo_vet.veterinaria.repositories.interfaces.I_MascotaRepository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.stereotype.Repository;

public class MascotaRepository {

}
