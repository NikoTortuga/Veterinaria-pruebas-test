package grupo_vet.veterinaria.repositories.interfaces;

public interface I_VentaRepository {

}
