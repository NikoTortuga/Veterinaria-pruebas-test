package grupo_vet.veterinaria.repositories.interfaces;

public class I_MascotaRepository {

}
