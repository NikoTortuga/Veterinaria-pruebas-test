package grupo_vet.veterinaria.repositories;

public class VentaDAO {

}
