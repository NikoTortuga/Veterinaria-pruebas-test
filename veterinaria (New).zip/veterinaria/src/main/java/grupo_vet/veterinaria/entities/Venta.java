package grupo_vet.veterinaria.entities;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Venta {
    private int id_venta;
    private String fecha;
    private int id_empleado;
    private int id_cliente;
    private BigDecimal monto_total;
}
