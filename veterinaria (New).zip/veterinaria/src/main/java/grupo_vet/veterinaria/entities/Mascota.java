package grupo_vet.veterinaria.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Mascota {
    private int id_mascota;
    private String nombre;
    private String especie;
    private String raza;
    private String edad_estimada;
    private String observaciones;
    private int id_cliente;
};

