package grupo_vet.veterinaria.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Empleado {
private int id_empleado;
private String nombre;
private String apellido;
private String DNI;
private String telefono;
private String correo;
}
