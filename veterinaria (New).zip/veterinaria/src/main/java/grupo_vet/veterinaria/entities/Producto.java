package grupo_vet.veterinaria.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Producto {
    private int id_producto;
    private String nombre;
    private BigDecimal precio;
    private int Stock;
    private String descripcion;
}
