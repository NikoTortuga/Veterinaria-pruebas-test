package grupo_vet.veterinaria.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import grupo_vet.veterinaria.entities.Cliente;
import grupo_vet.veterinaria.entities.Empleado;
import grupo_vet.veterinaria.entities.Mascota;
import grupo_vet.veterinaria.repositories.*;
import grupo_vet.veterinaria.repositories.interfaces.*;

 // La clase TestRepositories obtiene los DAOs y ejecuta operaciones para asegurar que funcionen
 // antes de crear el GUI

 // Se pone @Repository en los DAOs para que spring detecte que son objetos gestianados por Spring

 // El scan indica a Spring Boot que revise todos los componentes, crear y configurar
 // todas las piezas de la aplicación

@SpringBootApplication(scanBasePackages = "grupo_vet.veterinaria")

public class TestRepositories {
    public static void main(String[] args) {
        // ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class);
        /*
         * El método run devuelve el contexto de la aplicación.
         * Arranca la aplicación Spring Boot completa, esto significa que:
         * 1- va a leer el application.properties
         * 2- configurar el DataSource con HikariCP
         * 3- Si está configurado el spring.sql.init.mode=always, ejecuta el schema_DDL.sql
         * y data_DML, limpiando y repoblando nuestra base de datos.
         * 4- crea instancias de nuestros DAOs y les inyecta el DataSource, esto es lo que se
         * conoce como Inversión de Control o Inversión de Dependencias
         *
         * El objeto de ConfigurableApplicationContext  es el Contenedor de Inversión de Control
         * (IoC) de Spring Boot.
         * Es el corazón de Spring Boot, es el responsable de escanear el código en búsqueda de
         * anotaciones, cargar las configuraciones.
         */


         try (ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class,args);) {
          I_ClienteRepository clienteRepository = context.getBean(ClienteRepository.class);
          I_DatosVentaRepository datosVentaRepository = context.getBean(DatosVentaRepository.class);
          I_EmpleadoRepository empleadoRepository = context.getBean(EmpleadoRepository.class);
          I_MascotaRepository mascotaRepository = context.getBean(MascotaRepository.class);
          I_ProductoRepository productoRepository = context.getBean(ProductoRepository.class);
          I_VentaRepository ventaRepository = context.getBean(VentaRepository.class);


    // ************************** Pruebas de cliente ****************************************************

            // Test 1: Crear un cliente
            System.out.println("\n>>> Test 1: Crear Cliente");
            Cliente nuevoCliente = new Cliente(0, "Oliver", "Jackson", "15346723", "1122334455", "oliverjack@gmail.com");
            clienteRepository.create(nuevoCliente);
            if (nuevoCliente.getIdCliente() > 0) {
                System.out.println("Cliente creado correctamente con ID: " + nuevoCliente.getIdCliente());
                System.out.println(nuevoCliente);
            } else {
                System.err.println("Error, no se pudo crear un cliente");
            }

            // Test 2: Actualizar un cliente


            // Test 3: Filtrar un cliente


            // Test 4: Eliminar un cliente

            // Test 5: Mostrar

    // ************************** Pruebas de datos venta ****************************************************
           
            // Test 1: Crear un dato de venta

            // Test 2: Actualizar un dato de venta

            // Test 3: Filtrar un dato de venta

            // Test 4: Eliminar un dato de venta

    // ************************** Pruebas de empleado ****************************************************
           
            // Test 1: Crear un empleado
                    System.out.println("\n>>> Test 1: Crear empleado");
            Empleado nuevoEmpleado = new Empleado(0, "Jhon", "Workenson", "15445773", "1142854655", "JhonWork@gmail.com");
            empleadoRepository.create(nuevoEmpleado);
            if (nuevoCliente.getIdCliente() > 0) {
                System.out.println("Empleado creado correctamente con ID: " + nuevoEmpleado.getIdEmpleado());
                System.out.println(nuevoEmpleado);
            } else {
                System.err.println("Error, no se pudo crear un empleado");
            }

            // Test 2: Actualizar un empleado

            // Test 3: Filtrar un empleado

            // Test 4: Eliminar un empleado

    // ************************** Pruebas de mascota ****************************************************
            // Test 1: Crear una mascota
                 System.out.println("\n>>> Test 1: Crear mascota");
            Mascota nuevoMascota = new Mascota(0, "Perrin", "Perro", "Labrador", "entre 6 a 7 anios", "Operado en la pierna trasera izquierda", 12 );
            mascotaRepository.create(nuevoMascota);
            if (nuevoMascota.getIdMascota() > 0) {
                System.out.println("Mascota creada correctamente con ID: " + nuevoMascota.getIdMascota());
                System.out.println(nuevoMascota);
            } else {
                System.err.println("Error, no se pudo crear una Mascota");
            }
            
            // Test 2: Actualizar una mascota

            // Test 3: Filtrar una mascota

            // Test 4: Eliminar una mascota

    // ************************** Pruebas de producto ****************************************************
           
            // Test 1: Crear un producto

            // Test 2: Actualizar un producto

            // Test 3: Filtrar un producto

            // Test 4: Eliminar un producto

    // ************************** Pruebas de venta ****************************************************
           
            // Test 1: Crear una venta
    
            // Test 2: Actualizar una venta

            // Test 3: Filtrar una venta

            // Test 4: Eliminar una venta


        // ************************** Pruebas de venta ****************************************************


         } catch (Exception e) {
            System.err.println("Error en la base de datos");
            e.printStackTrace();
         }


       


    }
}
