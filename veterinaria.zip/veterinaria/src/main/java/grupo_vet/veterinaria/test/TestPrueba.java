package grupo_vet.veterinaria.test;
import grupo_vet.veterinaria.*;

public class TestPrueba {
    public static void main(String[] args) {
        System.out.println("Hola mundo");
    }

}
