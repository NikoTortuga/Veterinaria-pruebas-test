package grupo_vet.veterinaria.repositories.interfaces;

import grupo_vet.veterinaria.entities.DatosVenta;

import java.sql.SQLException;
import java.util.List;


public interface I_DatosVentaRepository {
    void create(DatosVenta datosVenta) throws SQLException;
    List<DatosVenta> findAll() throws SQLException;
    List<DatosVenta> findByIdVenta(int idVenta) throws SQLException;
    List<DatosVenta> findByIdProducto(int idProducto) throws SQLException;
    int update (DatosVenta datosVenta) throws SQLException;
    int delete(int idVenta, int idProducto) throws SQLException;
}

