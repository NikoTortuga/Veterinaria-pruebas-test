package grupo_vet.veterinaria.repositories;
import grupo_vet.veterinaria.entities.Mascota;
import grupo_vet.veterinaria.repositories.interfaces.I_MascotaRepository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.stereotype.Repository;

@Repository

public class MascotaRepository implements I_MascotaRepository {

    private final DataSource dataSource;

    private static final String SQL_CREATE =
            "INSERT INTO mascotas (nombre, especie, raza, edad_estimada, observaciones, id_cliente) VALUES (?, ?, ?, ?, ?, ?)";

    private static final String SQL_FIND_ALL =
            "SELECT * FROM mascotas";

    private static final String SQL_FIND_BY_ID_CLIENTE =
            "SELECT * FROM mascotas WHERE id_cliente = ?";

    private static final String SQL_UPDATE =
            "UPDATE mascotas SET nombre = ?, especie = ?, raza = ?, edad_estimada = ?, observaciones = ?, id_cliente = ? WHERE id_mascota = ?";

    private static final String SQL_DELETE =
            "DELETE FROM mascotas WHERE id_mascota = ?";

    public MascotaRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(Mascota mascota) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, mascota.getNombre());
            ps.setString(2, mascota.getEspecie());
            ps.setString(3, mascota.getRaza());
            ps.setString(4, mascota.getEdadEstimada());
            ps.setString(5, mascota.getObservaciones());
            ps.setInt(6, mascota.getIdCliente());
            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    mascota.setIdMascota(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public List<Mascota> findAll() throws SQLException {
        List<Mascota> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        }
        return lista;
    }

    @Override
    public List<Mascota> findByIdCliente(int idCliente) throws SQLException {
        List<Mascota> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID_CLIENTE)) {
            ps.setInt(1, idCliente);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    @Override
    public int update(Mascota mascota) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, mascota.getNombre());
            ps.setString(2, mascota.getEspecie());
            ps.setString(3, mascota.getRaza());
            ps.setString(4, mascota.getEdadEstimada());
            ps.setString(5, mascota.getObservaciones());
            ps.setInt(6, mascota.getIdCliente());
            ps.setInt(7, mascota.getIdMascota());
            return ps.executeUpdate();
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            return ps.executeUpdate();
        }
    }

    private Mascota mapRow(ResultSet rs) throws SQLException {
        Mascota mascota = new Mascota();
        mascota.setIdMascota(rs.getInt("id_mascota"));
        mascota.setNombre(rs.getString("nombre"));
        mascota.setEspecie(rs.getString("especie"));
        mascota.setRaza(rs.getString("raza"));
        mascota.setEdadEstimada(rs.getString("edad_estimada"));
        mascota.setObservaciones(rs.getString("observaciones"));
        mascota.setIdCliente(rs.getInt("id_cliente"));
        return mascota;
    }
}