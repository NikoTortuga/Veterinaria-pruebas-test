package grupo_vet.veterinaria.repositories.interfaces;

import grupo_vet.veterinaria.entities.Cliente;

import java.sql.SQLException;
import java.util.List;

// Reposiroty es una colección de memoria, que permite usar metodos sencillos
// Permite pensar en los datos como objetos en esta colección
// SQL. Trabaja directamente con las entidades

public interface I_ClienteRepository {
    void create(Cliente cliente) throws SQLException;
    Cliente findById(int id) throws SQLException;
    List<Cliente> findAll() throws SQLException;
    int update(Cliente cliente) throws SQLException;
    int delete(int id) throws SQLException;
}

