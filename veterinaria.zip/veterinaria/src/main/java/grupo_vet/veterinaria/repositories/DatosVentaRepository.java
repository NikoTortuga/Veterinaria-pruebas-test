package grupo_vet.veterinaria.repositories;
import grupo_vet.veterinaria.entities.DatosVenta;
import grupo_vet.veterinaria.repositories.interfaces.I_DatosVentaRepository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.stereotype.Repository;

@Repository

public class DatosVentaRepository implements I_DatosVentaRepository {

    private final DataSource dataSource;

    private static final String SQL_CREATE =
            "INSERT INTO datos_ventas (id_venta, id_producto, cantidad) VALUES (?, ?, ?)";

    private static final String SQL_FIND_ALL =
            "SELECT * FROM datos_ventas";

    private static final String SQL_FIND_BY_ID_VENTA =
            "SELECT * FROM datos_ventas WHERE id_venta = ?";

    private static final String SQL_FIND_BY_ID_PRODUCTO =
            "SELECT * FROM datos_ventas WHERE id_producto = ?";

    private static final String SQL_UPDATE =
            "UPDATE datos_ventas SET cantidad = ? WHERE id_venta = ? AND id_producto = ?";

    private static final String SQL_DELETE =
            "DELETE FROM datos_ventas WHERE id_venta = ? AND id_producto = ?";

    public DatosVentaRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(DatosVenta datosVenta) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE)) {

            ps.setInt(1, datosVenta.getIdVenta());
            ps.setInt(2, datosVenta.getIdProducto());
            ps.setInt(3, datosVenta.getCantidad());
            ps.executeUpdate();
        }
    }

    @Override
    public List<DatosVenta> findAll() throws SQLException {
        List<DatosVenta> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        }
        return lista;
    }

    @Override
    public List<DatosVenta> findByIdVenta(int idVenta) throws SQLException {
        List<DatosVenta> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID_VENTA)) {

            ps.setInt(1, idVenta);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    @Override
    public List<DatosVenta> findByIdProducto(int idProducto) throws SQLException {
        List<DatosVenta> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID_PRODUCTO)) {

            ps.setInt(1, idProducto);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    @Override
    public int update(DatosVenta datosVenta) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {

            ps.setInt(1, datosVenta.getCantidad());
            ps.setInt(2, datosVenta.getIdVenta());
            ps.setInt(3, datosVenta.getIdProducto());

            return ps.executeUpdate();
        }
    }

    @Override
    public int delete(int idVenta, int idProducto) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {

            ps.setInt(1, idVenta);
            ps.setInt(2, idProducto);
            return ps.executeUpdate();
        }
    }

    private DatosVenta mapRow(ResultSet rs) throws SQLException {
        DatosVenta dv = new DatosVenta();
        dv.setIdVenta(rs.getInt("id_venta"));
        dv.setIdProducto(rs.getInt("id_producto"));
        dv.setCantidad(rs.getInt("cantidad"));
        return dv;
    }
}
