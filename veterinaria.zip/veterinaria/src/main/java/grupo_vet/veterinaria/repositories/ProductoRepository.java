package grupo_vet.veterinaria.repositories;
import grupo_vet.veterinaria.entities.Producto;
import grupo_vet.veterinaria.repositories.interfaces.I_ProductoRepository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.stereotype.Repository;

@Repository

public class ProductoRepository implements I_ProductoRepository {

    private final DataSource dataSource;

    private static final String SQL_CREATE =
            "INSERT INTO productos (nombre, precio, stock, descripcion) VALUES (?, ?, ?, ?)";

    private static final String SQL_FIND_ALL =
            "SELECT * FROM productos";

    private static final String SQL_FIND_BY_NOMBRE =
            "SELECT * FROM productos WHERE nombre LIKE ?";

    private static final String SQL_UPDATE =
            "UPDATE productos SET nombre=?, precio=?, stock=?, descripcion=? WHERE id_producto=?";

    private static final String SQL_DELETE =
            "DELETE FROM productos WHERE id_producto=?";

    public ProductoRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(Producto producto) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, producto.getNombre());
            ps.setBigDecimal(2, producto.getPrecio());
            ps.setInt(3, producto.getStock());
            ps.setString(4, producto.getDescripcion());
            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    producto.setIdProducto(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public List<Producto> findAll() throws SQLException {
        List<Producto> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        }
        return lista;
    }

    @Override
    public List<Producto> findByNombre(String nombre) throws SQLException {
        List<Producto> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_NOMBRE)) {
            ps.setString(1, "%" + nombre + "%"); // Búsqueda parcial
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    @Override
    public int update(Producto producto) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, producto.getNombre());
            ps.setBigDecimal(2, producto.getPrecio());
            ps.setInt(3, producto.getStock());
            ps.setString(4, producto.getDescripcion());
            ps.setInt(5, producto.getIdProducto());
            return ps.executeUpdate();
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            return ps.executeUpdate();
        }
    }

    private Producto mapRow(ResultSet rs) throws SQLException {
        Producto producto = new Producto();
        producto.setIdProducto(rs.getInt("id_producto"));
        producto.setNombre(rs.getString("nombre"));
        producto.setPrecio(rs.getBigDecimal("precio"));
        producto.setStock(rs.getInt("stock"));
        producto.setDescripcion(rs.getString("descripcion"));
        return producto;
    }
}
